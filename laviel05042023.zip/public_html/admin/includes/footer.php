<!--footer-->
    <div class="footer">
       <p>&copy; 2023 Laviel's Salon | All Rights Reserved</p>
    </div>
        <!--//footer-->