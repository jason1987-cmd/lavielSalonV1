<div class="header">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

<style>    
img[alt*="000webhost"],
img[alt*="000webhost"][style],
img[src*="000webhost"],
img[src*="000webhost"][style],
body > div:nth-last-of-type(1)[style]{
	opacity: 0 !important;
	pointer-events:none !important;
	width: 0px !important;
	height: 0px !important;
	visibility:hidden !important;
	display:none !important;
}
</style>
    
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <a href="index.php"  style="display: block; text-align: center;">
                        <img src="images/logo.gif" alt="" style="max-width: 100%; height: auto;"></a>
                </div>
                <div class="col-lg-8 col-md-4 col-sm-12 col-xs-12">
                    <div class="navigation">
                        <div id="navigation">
                            <ul>
                                <li class="active"><a href="index.php" title="Home">Home</a></li>
                                <li><a href="service-list.php" title="Service List">Services</a></li>
                                <li><a href="appointment.php" title="Styleguide">Book Appointment</a> </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    

    