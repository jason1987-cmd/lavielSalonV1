<?php
session_start();
error_reporting(0);

include('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            background-color: #FFBF9B;
            color: #fff;
            font-family: Arial, sans-serif;
        }
    </style>
    
    <title>Laviel Salon || Home Page</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i%7cMontserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Style -->
    <link href="css/index1.css" rel="stylesheet">
</head>

<body>
    <?php include_once('includes/header.php');?>
    
    <div class="hero-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <h1 class="hero-title">The Salon That Follow Your Wants But Also Provide Your Needs.</h1>
                    <p class="hero-text"><strong>Your Types. Your Style. Your Color.</strong> </p>
                    <a href="appointment.php" class="btn btn-default">Make an Appointment</a> </div>
            </div>
        </div>
    </div>
   
	
	<div class="space-medium bg-default">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-5 col-sm-12 col-xs-12"><img src="images/about-img.png" alt="" class="img-responsive"></div>
                </div>
            </div>
        </div>
    </div>
   
   
   
   
   
   
   <style>    
img[alt*="000webhost"],
img[alt*="000webhost"][style],
img[src*="000webhost"],
img[src*="000webhost"][style],
body > div:nth-last-of-type(1)[style]{
	opacity: 0 !important;
	pointer-events:none !important;
	width: 0px !important;
	height: 0px !important;
	visibility:hidden !important;
	display:none !important;
}
</style>

   
    <?php include_once('includes/footer.php');?>
    <!-- /.footer-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menumaker.js"></script>
    <!-- sticky header -->
    <script src="js/jquery.sticky.js"></script>
    <script src="js/sticky-header.js"></script>
</body>
</html>
