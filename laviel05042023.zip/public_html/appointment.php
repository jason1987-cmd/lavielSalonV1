<?php
include('includes/dbconnection.php');
session_start();
error_reporting(0);


if (isset($_POST['submit'])) {

$aptnumber = mt_rand(100000000, 999999999);
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$adate = $_POST['adate'];
$atime = $_POST['atime'];
$services = $_POST['services'];
$image = $_POST['image'];

    // Check if email is not empty
    if (!empty($email)) {
        // Validate email format
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Perform database insertion
            $query = mysqli_query($con, "INSERT INTO tblappointment (AptNumber,Name,Email,PhoneNumber,AptDate,AptTime,Services,Image) VALUES 
            ('$aptnumber', '$name','$email','$phone','$adate','$atime','$services', '$image')");


            // Check if insertion was successful
            if ($query) {
                echo "<script>alert('You submitted successfully!');</script>";
                echo "<script>window.location.href = 'index.php'</script>";
            } else {
                echo '<script>alert("Something went wrong. Please try again.")</script>';
            }
        } else {
            echo '<script>alert("Invalid email format. Please try again.")</script>';
        }
    } else {
        echo '<script>alert("Email is required. Please try again.")</script>';
    }

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Laviel Salon || Appointments Form</title>
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i%7cMontserrat:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">
  <!-- Font Awesome -->
  <link href="css/font-awesome.min.css" rel="stylesheet">
<!--[endif]-->
</head>

<body>
  <?php include_once('includes/header.php'); ?>
  <div class="content">
    <div class="container">
      <div class="row">

        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <h1>Appointment Form</h1>
              <p>Bookking an appointment needs a down payment of P100 to secure it, through GCASH.</p>
              <p>
              <h5>G-CASH Number: 0915-551-7080 <br>Account Name: Jason Dungca</br></h5>
              </p>
              <form method="post">
                <div class="row">
                  <div class="col-md-6">
                    <label class="control-label" for="name">Name</label>
                    <input type="text" class="form-control" id="name" placeholder="Name" name="name" required="true pattern="[A-Za-z]+">
                  </div>
                  <div class="col-md-6">
                    <label class="control-label" for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" required="true"
                      maxlength="10" pattern="[0-9]+">
                  </div>
                  <div class="col-md-6">
                    <label class="control-label" for="email">Email</label>
                    <input type="email" class="form-control" id="email" placeholder="Email" name="email"
                      required="true">
                  </div>
                  <div class="col-md-6">
                    <label class="control-label" for="Subject">Services</label>
                    <select name="services" id="services" required="true" class="form-control">
                      <option value="">Select Services</option>
                      <?php $query = mysqli_query($con, "select * from tblservices");
                      while ($row = mysqli_fetch_array($query)) {
                        ?>
                        <option value="<?php echo $row['ServiceName']; ?>"><?php echo $row['ServiceName']; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                  
                  <div class="container">
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="control-label" for="adate">Appointment Date</label>
                          <input type="date" class="form-control" placeholder="Date" id="adate" name="adate"
                            required="true">
                        </div>
                      </div>
                      
                      
                  <div class="container">
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="control-label" for="atime">Appointment Time</label>
                          <input type="time" class="form-control" placeholder="Time" id="atime" name="atime"
                            required="true">
                        </div>
                      </div>


                    <div class="container">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <form action="upload.php" method="post" enctype="multipart/form-data">
                                <label class="control-label" for="textarea">Upload the Proof of Payment</label>
                                <input type="file" placeholder="Images" name="images" id="images" required="true">
                              </form>
                            </div>
                          </div>
                        </div> 


                        <div class="col-md-12">
                          <div class="form-group">
                            <button type="submit" id="submit" name="submit" class="btn btn-default">Book</button>
                          </div>
                        </div>
                      </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<div>
    <p>
        
    </p>
</div>


<style>
    bg-primary {
    color: #fff;
    background-color: #fff;
}
</style>



<div>
    <div class="space-small bg-primary= color: #fff;">
        <!-- call to action -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-sm-7 col-md-8 col-xs-12">
                    <h1 class="cta-title" style="background-color: #FFA559; border: 2px solid yellow; padding: 10px; border-radius: 10px;">    "Exit like a Goddess at Laviel's Salon!"</h1></br>
                </div>
            </div>
        </div>
    </div>
    
    
     
     
<?php
include('includes/dbconnection.php');
session_start();
error_reporting(0);

if (isset($_POST['sub'])) {

    $email = $_POST['email'];

    // Check if email is not empty
    if (!empty($email)) {
        // Validate email format
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Perform database insertion
            $query = mysqli_query($con, "INSERT INTO tblsubscriber (Email) VALUES ('$email')");

            // Check if insertion was successful
            if ($query) {
                echo "<script>alert('You subscribed successfully!');</script>";
                echo "<script>window.location.href = 'index.php'</script>";
            } else {
                echo '<script>alert("Something went wrong. Please try again.")</script>';
            }
        } else {
            echo '<script>alert("Invalid email format. Please try again.")</script>';
        }
    } else {
        echo '<script>alert("Email is required. Please try again.")</script>';
    }

}
?>
</br>


<style>
      /* Hero Section */
        .hero-section {
            background-color: #FFA559;
            padding: 60px 0;
        }

        .hero-title {
            color: #FFF;
            font-size: 36px;
            font-weight: bold;
            margin-top: 0;
        }

        .hero-text {
            color: #FFF;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 30px;
        }

        .btn.btn-default {
            background-color: #FFA559;
            color: #FFF;
            font-size: 18px;
            font-weight: bold;
            padding: 15px 30px;
            border-radius: 50px;
            transition: background-color 0.3s ease;
        }

        .btn.btn-default:hover {
            background-color: #FF6000;
        }

        /* Space Medium Section */
        .space-medium {
            background-color: #FFBF9B;
            padding: 60px 0;
        }

        .bg-default {
            background-color: #FFBF9B;
        }

        .img-responsive {
            max-width: 100%;
            height: auto;
        }

        /* Footer Section */
        .footer {
            background-color: ;
            padding: 60px 0;
        }

        .widget-title {
            color: #FFF;
            font-size: 24px;
            font-weight: bold;
            margin-top: 0;
            margin-bottom: 20px;
        }

        .contact li {
            color: #FFF;
            font-size: 20px;
            list-style-type: none;
            margin-bottom: 10px;
        }

        .footer-social ul li {
            display: inline-block;
            margin-right: 10px;
        }

        .footer-social ul li a {
            color: #FFF;
            font-size: 25px;
            transition: color 0.3s ease;
        }

        .footer-social ul li a:hover {
            color: #FFA559;
        }

        .widget-newsletter {
            margin-top: 15;
        }

        .widget-newsletter p {
            color: #FFF;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .form-control {
            border-radius: 100px;
            height: 50px;
            font-size: 16px;
        }

        .input-group-btn .btn {
            border-radius: 50px;
            padding: 13px 30px;
            font-size: 16px;
            font-weight: bold;
            background-color: #FFA559;
            color: #FFF;
            transition: background-color 0.3s ease;
        }

        .input-group-btn .btn:hover {
            background-color: #FF6000;
        }

        .tiny-footer {
            background-color: #FFBF9B;
            margin-top: 30px;
            padding: 15px 0;
        }

        .copyright-content {
            text-align: center;
            color: #FFF;
            font-size: 14px;
            margin-bottom: 0;
        }
</style>









<div class="footer">
    <!-- footer-->
    <div class="container">
        <div class="footer-block">
            <!-- footer block -->
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="footer-widget">
                        <h2 class="widget-title">SALON INFO</h2>
                        <ul class="listnone contact">
                            <li><i class="fa fa-map-marker"></i> C&S Building, Tarlac 2300 </li>
                            <li><i class="fa fa-phone"></i> +63 (915) 551-7080</li>
                            <li><i class="fa fa-calendar"></i> 08:00 am to 05:00 pm</li>
                            <li><i class="fa fa-envelope-o"></i> lavielsalon@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-widget footer-social">
                        <!-- social block -->
                        <h2 class="widget-title">Social Feed</h2>
                        <ul class="listnone">
                            <li>
                                <a href="#"> <i class="fa fa-facebook"></i> Facebook </a>
                            </li>
                            <li><a href="#"><i class="fa fa-twitter"></i> Twitter</a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i> Instagram</a></li>
                            <li>
                                <a href="#"> <i class="fa fa-youtube"></i>Youtube</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.social block -->
                </div>
                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <div class="footer-widget widget-newsletter">
                        <!-- newsletter block -->
                        <h2 class="widget-title">Subcription Box</h2>
                        <p>Enter your email address to receive a coupon and or discount right to your inbox for new
                            customers and great benefits for old customers.</p>
                        <form method="post">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Enter your email address"
                                    name="email">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="submit" value="submit"
                                        name="sub">Subscribe</button>
                                </span>
                            </div>
                        </form>
                        <!-- /input-group -->
                    </div>
                    <!-- newsletter block -->
                </div>
            </div>
            <div class="tiny-footer">
                <!-- tiny footer block -->
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="copyright-content">
                            <p>© Laviel Salon 2023 | All Rights Resereved</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.tiny footer block -->
        </div>
        <!-- /.footer block -->
    </div>
</div>
     
     
    
</div>




 


  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.min.js"></script>
  <script src="js/menumaker.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/sticky-header.js"></script>

</body>
</html>

