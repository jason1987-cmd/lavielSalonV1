CREATE DATABASE your_dbname; -- Replace "your_dbname" with your preferred database name
USE your_dbname;

CREATE TABLE images (
  id INT(11) AUTO_INCREMENT PRIMARY KEY,
  image_name VARCHAR(255)
);

